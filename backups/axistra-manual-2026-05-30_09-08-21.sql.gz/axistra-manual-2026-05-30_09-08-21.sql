--
-- PostgreSQL database dump
--

\restrict mz8KeBqdSfyr0lzDtUhppbXxIUxbSXJc27aw1bN0oNEDhY0yCKqNU9mCIL3B4U5

-- Dumped from database version 15.18 (Debian 15.18-0+deb12u1)
-- Dumped by pg_dump version 15.18 (Debian 15.18-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    actor_id character varying,
    actor_email character varying,
    action character varying NOT NULL,
    entity_type character varying,
    entity_id character varying,
    details text,
    ip_address character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: compliance_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id character varying NOT NULL,
    risk_level character varying DEFAULT 'Low'::character varying NOT NULL,
    action character varying NOT NULL,
    notes text,
    blocked boolean DEFAULT false NOT NULL,
    high_volume_flag boolean DEFAULT false NOT NULL,
    refund_amount character varying,
    refund_currency character varying,
    kyc_requested_at timestamp without time zone,
    document_url character varying,
    admin_comment text,
    created_by character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: crypto_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crypto_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    recharge_id character varying NOT NULL,
    customer_id character varying NOT NULL,
    crypto_amount numeric(18,8) NOT NULL,
    coin character varying DEFAULT 'USDT'::character varying NOT NULL,
    network character varying DEFAULT 'TRC20'::character varying NOT NULL,
    receiving_wallet character varying,
    receiving_wallet_tag character varying,
    tx_hash character varying NOT NULL,
    gateway_invoice_id character varying,
    gateway_track_id character varying,
    gateway_tx_status character varying,
    sender_address character varying,
    sent_amount numeric(18,8),
    sent_value numeric(18,8),
    received_amount numeric(18,8),
    received_value numeric(18,8),
    gateway_rate numeric(18,8),
    confirmations character varying,
    auto_convert_amount numeric(18,8),
    auto_convert_currency character varying,
    final_usdt_amount numeric(18,8),
    raw_gateway_payload text,
    wallet_balance_after numeric(18,8),
    aed_rate_at_payment numeric(12,4),
    aed_value numeric(18,2),
    status character varying DEFAULT 'received'::character varying NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_code character varying NOT NULL,
    magnus_username character varying,
    first_name character varying,
    last_name character varying,
    full_name character varying NOT NULL,
    company_name character varying,
    email character varying,
    phone character varying,
    telegram character varying,
    address text,
    country character varying,
    id_number character varying,
    signup_ip character varying,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    risk_level character varying DEFAULT 'Low'::character varying NOT NULL,
    kyc_status character varying DEFAULT 'not_required'::character varying NOT NULL,
    last_login_at timestamp without time zone,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    expense_code character varying,
    expense_date timestamp without time zone NOT NULL,
    vendor_id character varying,
    vendor_name character varying NOT NULL,
    category character varying NOT NULL,
    amount numeric(18,2) NOT NULL,
    currency character varying DEFAULT 'AED'::character varying NOT NULL,
    payment_method character varying DEFAULT 'Bank'::character varying NOT NULL,
    bank_name character varying,
    source_wallet character varying,
    paid_in_usdt boolean DEFAULT false NOT NULL,
    vendor_wallet character varying,
    crypto_network character varying,
    tx_hash character varying,
    aed_rate numeric(12,4),
    aed_value numeric(18,2),
    bank_reference character varying,
    receipt_url character varying,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    invoice_number character varying NOT NULL,
    customer_id character varying NOT NULL,
    recharge_id character varying,
    customer_name character varying NOT NULL,
    customer_email character varying,
    customer_country character varying,
    customer_company character varying,
    customer_phone character varying,
    customer_address text,
    service_name character varying DEFAULT 'SaaS Platform Usage Credits'::character varying NOT NULL,
    service_description text DEFAULT 'Prepaid credits for usage of Axistra cloud software platform and related digital services.'::text NOT NULL,
    amount numeric(18,2) NOT NULL,
    currency character varying DEFAULT 'USD'::character varying NOT NULL,
    payment_method character varying,
    crypto_coin character varying,
    crypto_network character varying,
    tx_hash character varying,
    status character varying DEFAULT 'unpaid'::character varying NOT NULL,
    issued_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: kyc_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kyc_documents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id character varying NOT NULL,
    document_type character varying NOT NULL,
    file_name character varying NOT NULL,
    file_url character varying,
    status character varying DEFAULT 'submitted'::character varying NOT NULL,
    admin_comment text,
    reviewed_by character varying,
    reviewed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leads (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying,
    email character varying NOT NULL,
    company character varying,
    phone character varying,
    message text,
    source character varying DEFAULT 'website'::character varying NOT NULL,
    status character varying DEFAULT 'new'::character varying NOT NULL,
    ip_address character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: magnus_sync_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.magnus_sync_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    recharge_id character varying,
    magnus_username character varying,
    action character varying NOT NULL,
    status character varying DEFAULT 'success'::character varying NOT NULL,
    request_payload text,
    response_payload text,
    error_message text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: payment_webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_webhooks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    source character varying NOT NULL,
    external_event_id character varying,
    gateway_invoice_id character varying,
    tx_hash character varying,
    recharge_id character varying,
    processed boolean DEFAULT false NOT NULL,
    error_message text,
    raw_payload text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: receiving_wallets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.receiving_wallets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    gateway character varying(24) NOT NULL,
    coin character varying(16) NOT NULL,
    network character varying(32) NOT NULL,
    address character varying(255) NOT NULL,
    label character varying(120),
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: recharges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recharges (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    recharge_code character varying NOT NULL,
    customer_id uuid NOT NULL,
    invoice_id character varying,
    invoice_number character varying,
    magnus_username character varying,
    amount numeric(18,2) NOT NULL,
    currency character varying DEFAULT 'USD'::character varying NOT NULL,
    crypto_amount numeric(18,8) DEFAULT '0'::numeric NOT NULL,
    crypto_coin character varying DEFAULT 'USDT'::character varying NOT NULL,
    crypto_network character varying DEFAULT 'TRC20'::character varying NOT NULL,
    wallet_address character varying,
    tx_hash character varying,
    payment_gateway character varying DEFAULT 'Manual'::character varying NOT NULL,
    payment_date timestamp without time zone,
    magnus_credit_added numeric(18,2),
    magnus_reference_id character varying,
    magnus_credited_at timestamp without time zone,
    status character varying DEFAULT 'pending_payment'::character varying NOT NULL,
    reconciled boolean DEFAULT false NOT NULL,
    reconciliation_note text,
    admin_notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    key character varying NOT NULL,
    value text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: treasury_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treasury_batches (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    batch_code character varying NOT NULL,
    name character varying NOT NULL,
    period_start timestamp without time zone,
    period_end timestamp without time zone,
    status character varying DEFAULT 'open'::character varying NOT NULL,
    source_gateway character varying,
    source_wallet character varying,
    destination_exchange character varying,
    destination_wallet character varying,
    settlement_tx_hash character varying,
    settlement_reference character varying,
    coin character varying,
    network character varying,
    total_crypto_amount numeric(18,8),
    total_invoice_amount numeric(18,2),
    invoice_currency character varying,
    transfer_fee_crypto numeric(18,8),
    received_crypto_amount numeric(18,8),
    exchange_received_at timestamp without time zone,
    usdt_amount numeric(18,8),
    usdt_conversion_rate numeric(18,8),
    usdt_conversion_date timestamp without time zone,
    usdt_conversion_reference character varying,
    crypto_converted numeric(18,8),
    conversion_rate numeric(12,4),
    fiat_received numeric(18,2),
    fiat_currency character varying,
    conversion_date timestamp without time zone,
    bank_name character varying,
    bank_reference character varying,
    bank_deposit_date timestamp without time zone,
    bank_fee_aed numeric(18,2),
    net_bank_deposit_amount numeric(18,2),
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: treasury_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treasury_movements (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    recharge_id character varying NOT NULL,
    customer_id character varying NOT NULL,
    treasury_batch_id character varying,
    total_usdt_received numeric(18,8) DEFAULT '0'::numeric NOT NULL,
    source_currency_summary text,
    source_transaction_details text,
    receiving_wallet character varying,
    receiving_wallet_tag character varying,
    receive_tx_hash character varying,
    transferred_to_okx boolean DEFAULT false NOT NULL,
    okx_deposit_tx_hash character varying,
    okx_account_reference character varying,
    okx_transfer_date timestamp without time zone,
    converted_to_aed boolean DEFAULT false NOT NULL,
    usdt_converted numeric(18,8),
    okx_conversion_rate numeric(12,4),
    aed_received numeric(18,2),
    conversion_date timestamp without time zone,
    transferred_to_wio boolean DEFAULT false NOT NULL,
    wio_bank_reference character varying,
    wio_deposit_date timestamp without time zone,
    wio_aed_amount numeric(18,2),
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: users_admin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_admin (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying NOT NULL,
    password_hash character varying NOT NULL,
    full_name character varying DEFAULT 'Admin'::character varying NOT NULL,
    role character varying DEFAULT 'admin'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp without time zone,
    last_login_ip character varying,
    two_fa_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(160) NOT NULL,
    type character varying(60),
    contact character varying(255),
    default_wallet character varying(24),
    default_payment_method character varying(32),
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: wallet_ledgers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallet_ledgers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    wallet character varying(20) NOT NULL,
    coin character varying(12) NOT NULL,
    network character varying(24),
    amount numeric(30,10) NOT NULL,
    tx_type character varying(20) NOT NULL,
    original_coin character varying(12),
    original_amount numeric(30,10),
    linked_recharge_id character varying,
    linked_batch_id character varying,
    linked_expense_id character varying,
    linked_invoice_id character varying,
    linked_ledger_id character varying,
    tx_hash character varying,
    external_ref character varying,
    counterparty character varying,
    rate_used numeric(18,8),
    fee_amount numeric(30,10),
    fee_currency character varying(12),
    aed_value_at_event numeric(18,2),
    notes text,
    actor_email character varying,
    event_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, actor_id, actor_email, action, entity_type, entity_id, details, ip_address, created_at) FROM stdin;
fd2b3079-ca61-43f4-a9ca-41babeed96ce	ce15bb18-2db8-4636-b786-d09b4009b376	admin@axistratech.com	login	admin_user	ce15bb18-2db8-4636-b786-d09b4009b376	\N	127.0.0.1	2026-05-30 09:01:57.161174
e3e93cfb-7f6e-46e0-a60d-3dfcf85b6d9f	ce15bb18-2db8-4636-b786-d09b4009b376	admin@axistratech.com	backup_restore	backup	axistra-manual-2026-05-30_09-02-03.sql.gz	Restored from axistra-manual-2026-05-30_09-02-03.sql.gz. Safety snapshot: axistra-manual-2026-05-30_09-07-33.sql.gz	\N	2026-05-30 09:07:34.040583
f26ef137-1005-46ba-a691-af87541d27d3	ce15bb18-2db8-4636-b786-d09b4009b376	admin@axistratech.com	login	admin_user	ce15bb18-2db8-4636-b786-d09b4009b376	\N	34.16.56.64,172.70.126.14,34.160.159.238	2026-05-30 09:07:36.300412
ae863a80-69a2-4215-8c79-0a02cbce8c83	ce15bb18-2db8-4636-b786-d09b4009b376	admin@axistratech.com	login	admin_user	ce15bb18-2db8-4636-b786-d09b4009b376	\N	34.16.56.64,104.22.62.17,34.160.159.238	2026-05-30 09:08:18.507389
f32c7bcf-95c1-4c9e-82dc-bb2452e7428b	5f7d396e-92f3-4805-9498-639434022016	TEST_acct_e0046421@axistratech.com	login	admin_user	5f7d396e-92f3-4805-9498-639434022016	\N	34.16.56.64,172.70.131.134,34.160.159.238	2026-05-30 09:08:18.910322
5f09b86b-9338-4535-a085-140330121bdd	ce15bb18-2db8-4636-b786-d09b4009b376	admin@axistratech.com	backup_manual	backup	axistra-manual-2026-05-30_09-08-19.sql.gz	6.1 KB	\N	2026-05-30 09:08:19.368214
c6db74b2-3a44-49d7-93bf-1cf9968b92f3	ce15bb18-2db8-4636-b786-d09b4009b376	admin@axistratech.com	backup_upload	backup	TEST_upload_11921fca.sql.gz	Uploaded 6.1 KB	\N	2026-05-30 09:08:20.017454
a7d7e7e0-18c9-42fa-b3a0-203dbb4052fb	ce15bb18-2db8-4636-b786-d09b4009b376	admin@axistratech.com	backup_delete	backup	TEST_upload_11921fca.sql.gz	Deleted TEST_upload_11921fca.sql.gz	\N	2026-05-30 09:08:20.411953
\.


--
-- Data for Name: compliance_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_logs (id, customer_id, risk_level, action, notes, blocked, high_volume_flag, refund_amount, refund_currency, kyc_requested_at, document_url, admin_comment, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: crypto_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.crypto_transactions (id, recharge_id, customer_id, crypto_amount, coin, network, receiving_wallet, receiving_wallet_tag, tx_hash, gateway_invoice_id, gateway_track_id, gateway_tx_status, sender_address, sent_amount, sent_value, received_amount, received_value, gateway_rate, confirmations, auto_convert_amount, auto_convert_currency, final_usdt_amount, raw_gateway_payload, wallet_balance_after, aed_rate_at_payment, aed_value, status, notes, created_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, customer_code, magnus_username, first_name, last_name, full_name, company_name, email, phone, telegram, address, country, id_number, signup_ip, status, risk_level, kyc_status, last_login_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, expense_code, expense_date, vendor_id, vendor_name, category, amount, currency, payment_method, bank_name, source_wallet, paid_in_usdt, vendor_wallet, crypto_network, tx_hash, aed_rate, aed_value, bank_reference, receipt_url, notes, created_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, invoice_number, customer_id, recharge_id, customer_name, customer_email, customer_country, customer_company, customer_phone, customer_address, service_name, service_description, amount, currency, payment_method, crypto_coin, crypto_network, tx_hash, status, issued_date, created_at) FROM stdin;
\.


--
-- Data for Name: kyc_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kyc_documents (id, customer_id, document_type, file_name, file_url, status, admin_comment, reviewed_by, reviewed_at, created_at) FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leads (id, first_name, last_name, email, company, phone, message, source, status, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: magnus_sync_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.magnus_sync_logs (id, recharge_id, magnus_username, action, status, request_payload, response_payload, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: payment_webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_webhooks (id, source, external_event_id, gateway_invoice_id, tx_hash, recharge_id, processed, error_message, raw_payload, created_at) FROM stdin;
\.


--
-- Data for Name: receiving_wallets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.receiving_wallets (id, gateway, coin, network, address, label, notes, is_active, created_at, updated_at) FROM stdin;
678e9b39-a47a-4d49-9c7a-e3a49d3a7a43	Binance	BTC	BTC	129ifR1iQyY4fWkq3G8MXCMwReZZHhqfkt	Binance Main BTC	\N	t	2026-05-30 09:01:37.289624	2026-05-30 09:01:37.289624
ad61dfb7-68ce-417f-a945-1562dce105d9	OKX	BTC	BTC	bc1q3a4gskudn4kd3curm5yxjfnk2ey0zldv3v023wjyu29e0jwxg9ksx38sjj	OKX Main BTC	\N	t	2026-05-30 09:01:37.292527	2026-05-30 09:01:37.292527
\.


--
-- Data for Name: recharges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recharges (id, recharge_code, customer_id, invoice_id, invoice_number, magnus_username, amount, currency, crypto_amount, crypto_coin, crypto_network, wallet_address, tx_hash, payment_gateway, payment_date, magnus_credit_added, magnus_reference_id, magnus_credited_at, status, reconciled, reconciliation_note, admin_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (key, value, updated_at) FROM stdin;
\.


--
-- Data for Name: treasury_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.treasury_batches (id, batch_code, name, period_start, period_end, status, source_gateway, source_wallet, destination_exchange, destination_wallet, settlement_tx_hash, settlement_reference, coin, network, total_crypto_amount, total_invoice_amount, invoice_currency, transfer_fee_crypto, received_crypto_amount, exchange_received_at, usdt_amount, usdt_conversion_rate, usdt_conversion_date, usdt_conversion_reference, crypto_converted, conversion_rate, fiat_received, fiat_currency, conversion_date, bank_name, bank_reference, bank_deposit_date, bank_fee_aed, net_bank_deposit_amount, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: treasury_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.treasury_movements (id, recharge_id, customer_id, treasury_batch_id, total_usdt_received, source_currency_summary, source_transaction_details, receiving_wallet, receiving_wallet_tag, receive_tx_hash, transferred_to_okx, okx_deposit_tx_hash, okx_account_reference, okx_transfer_date, converted_to_aed, usdt_converted, okx_conversion_rate, aed_received, conversion_date, transferred_to_wio, wio_bank_reference, wio_deposit_date, wio_aed_amount, notes, created_at) FROM stdin;
\.


--
-- Data for Name: users_admin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_admin (id, email, password_hash, full_name, role, is_active, last_login_at, last_login_ip, two_fa_enabled, created_at, updated_at) FROM stdin;
ce15bb18-2db8-4636-b786-d09b4009b376	admin@axistratech.com	$2a$10$FEsquPelAhelshwMokBSHuW9CaEltlg4/1A55TpQyJih6xraHQ6zW	Axistra Admin	admin	t	2026-05-30 09:08:18.477	34.16.56.64,104.22.62.17,34.160.159.238	f	2026-05-30 09:01:37.283522	2026-05-30 09:08:18.480857
5f7d396e-92f3-4805-9498-639434022016	TEST_acct_e0046421@axistratech.com	$2a$10$u/erTANIvXDMNxkPJpd.iOZZcF/vHT.6zwyDinZVnRWaKzqpiHewu	Test Acct	accountant	t	2026-05-30 09:08:18.906	34.16.56.64,172.70.131.134,34.160.159.238	f	2026-05-30 09:08:18.71161	2026-05-30 09:08:18.907583
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, name, type, contact, default_wallet, default_payment_method, notes, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: wallet_ledgers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wallet_ledgers (id, wallet, coin, network, amount, tx_type, original_coin, original_amount, linked_recharge_id, linked_batch_id, linked_expense_id, linked_invoice_id, linked_ledger_id, tx_hash, external_ref, counterparty, rate_used, fee_amount, fee_currency, aed_value_at_event, notes, actor_email, event_at, created_at) FROM stdin;
\.


--
-- Name: kyc_documents PK_02e49877f1578e6285f84e57ab6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kyc_documents
    ADD CONSTRAINT "PK_02e49877f1578e6285f84e57ab6" PRIMARY KEY (id);


--
-- Name: treasury_batches PK_068d14fa620d4276fdac75a299a; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_batches
    ADD CONSTRAINT "PK_068d14fa620d4276fdac75a299a" PRIMARY KEY (id);


--
-- Name: compliance_logs PK_0f10ef25e2593d957c2a38873c0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_logs
    ADD CONSTRAINT "PK_0f10ef25e2593d957c2a38873c0" PRIMARY KEY (id);


--
-- Name: customers PK_133ec679a801fab5e070f73d3ea; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT "PK_133ec679a801fab5e070f73d3ea" PRIMARY KEY (id);


--
-- Name: treasury_movements PK_15e5349eb0e63c75ef678e08882; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_movements
    ADD CONSTRAINT "PK_15e5349eb0e63c75ef678e08882" PRIMARY KEY (id);


--
-- Name: recharges PK_19efa203cefcf8cf544d7ea7e33; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recharges
    ADD CONSTRAINT "PK_19efa203cefcf8cf544d7ea7e33" PRIMARY KEY (id);


--
-- Name: audit_logs PK_1bb179d048bbc581caa3b013439; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "PK_1bb179d048bbc581caa3b013439" PRIMARY KEY (id);


--
-- Name: users_admin PK_4f0f50d9922a0ed51c214f5556b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_admin
    ADD CONSTRAINT "PK_4f0f50d9922a0ed51c214f5556b" PRIMARY KEY (id);


--
-- Name: invoices PK_668cef7c22a427fd822cc1be3ce; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "PK_668cef7c22a427fd822cc1be3ce" PRIMARY KEY (id);


--
-- Name: payment_webhooks PK_676045943e5ab1ef7cdaa86a5b9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_webhooks
    ADD CONSTRAINT "PK_676045943e5ab1ef7cdaa86a5b9" PRIMARY KEY (id);


--
-- Name: magnus_sync_logs PK_8d16f3f7696ed8b07456c5b5935; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.magnus_sync_logs
    ADD CONSTRAINT "PK_8d16f3f7696ed8b07456c5b5935" PRIMARY KEY (id);


--
-- Name: expenses PK_94c3ceb17e3140abc9282c20610; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "PK_94c3ceb17e3140abc9282c20610" PRIMARY KEY (id);


--
-- Name: vendors PK_9c956c9797edfae5c6ddacc4e6e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT "PK_9c956c9797edfae5c6ddacc4e6e" PRIMARY KEY (id);


--
-- Name: receiving_wallets PK_b17822c9b6dbe0f4d1a51a9dbe6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receiving_wallets
    ADD CONSTRAINT "PK_b17822c9b6dbe0f4d1a51a9dbe6" PRIMARY KEY (id);


--
-- Name: wallet_ledgers PK_c446b606d94662dce5691c84d8c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_ledgers
    ADD CONSTRAINT "PK_c446b606d94662dce5691c84d8c" PRIMARY KEY (id);


--
-- Name: settings PK_c8639b7626fa94ba8265628f214; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT "PK_c8639b7626fa94ba8265628f214" PRIMARY KEY (key);


--
-- Name: leads PK_cd102ed7a9a4ca7d4d8bfeba406; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT "PK_cd102ed7a9a4ca7d4d8bfeba406" PRIMARY KEY (id);


--
-- Name: crypto_transactions PK_ea984bfd1336c3298198a2d6783; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crypto_transactions
    ADD CONSTRAINT "PK_ea984bfd1336c3298198a2d6783" PRIMARY KEY (id);


--
-- Name: users_admin UQ_23b4b9ed689230fb3af339412ef; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_admin
    ADD CONSTRAINT "UQ_23b4b9ed689230fb3af339412ef" UNIQUE (email);


--
-- Name: expenses UQ_3dbe029eca3adea66e527acd32b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "UQ_3dbe029eca3adea66e527acd32b" UNIQUE (expense_code);


--
-- Name: treasury_batches UQ_918609d35bfbd49241d9d9a3d15; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_batches
    ADD CONSTRAINT "UQ_918609d35bfbd49241d9d9a3d15" UNIQUE (batch_code);


--
-- Name: recharges UQ_a536b9aa3dad7a3e57d4fab85c4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recharges
    ADD CONSTRAINT "UQ_a536b9aa3dad7a3e57d4fab85c4" UNIQUE (recharge_code);


--
-- Name: customers UQ_acd5656a9fa7cf04125f0848165; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT "UQ_acd5656a9fa7cf04125f0848165" UNIQUE (customer_code);


--
-- Name: invoices UQ_d8f8d3788694e1b3f96c42c36fb; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "UQ_d8f8d3788694e1b3f96c42c36fb" UNIQUE (invoice_number);


--
-- Name: IDX_0c7f3a8810f6ccdae248319549; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_0c7f3a8810f6ccdae248319549" ON public.receiving_wallets USING btree (gateway, coin, network);


--
-- Name: IDX_35a20a930e66cf998f408a4d35; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_35a20a930e66cf998f408a4d35" ON public.wallet_ledgers USING btree (linked_batch_id);


--
-- Name: IDX_79580f46233f21b9cfa546333a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_79580f46233f21b9cfa546333a" ON public.receiving_wallets USING btree (address);


--
-- Name: IDX_83065ec2a2c5052786c122e95b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_83065ec2a2c5052786c122e95b" ON public.vendors USING btree (name);


--
-- Name: IDX_8ee0a0b7aa96f9c16edeb6bfe6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_8ee0a0b7aa96f9c16edeb6bfe6" ON public.payment_webhooks USING btree (external_event_id);


--
-- Name: IDX_918609d35bfbd49241d9d9a3d1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_918609d35bfbd49241d9d9a3d1" ON public.treasury_batches USING btree (batch_code);


--
-- Name: IDX_a536b9aa3dad7a3e57d4fab85c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_a536b9aa3dad7a3e57d4fab85c" ON public.recharges USING btree (recharge_code);


--
-- Name: IDX_a64194a1de5402443ea3bd6e66; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_a64194a1de5402443ea3bd6e66" ON public.wallet_ledgers USING btree (linked_recharge_id);


--
-- Name: IDX_acd5656a9fa7cf04125f084816; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_acd5656a9fa7cf04125f084816" ON public.customers USING btree (customer_code);


--
-- Name: IDX_b31db5c05b073f14d86a36e4f1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_b31db5c05b073f14d86a36e4f1" ON public.payment_webhooks USING btree (gateway_invoice_id);


--
-- Name: IDX_b3eea7add0e16594dba102716c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_b3eea7add0e16594dba102716c" ON public.leads USING btree (email);


--
-- Name: IDX_c9dca0fd27a45646b3c43299d6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_c9dca0fd27a45646b3c43299d6" ON public.wallet_ledgers USING btree (event_at);


--
-- Name: IDX_cc4ed204cc0d1a8a2092e7438a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cc4ed204cc0d1a8a2092e7438a" ON public.wallet_ledgers USING btree (wallet, coin, event_at);


--
-- Name: IDX_d30f6a483a032bc38d519047ad; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_d30f6a483a032bc38d519047ad" ON public.crypto_transactions USING btree (tx_hash);


--
-- Name: IDX_d7add7954f86bd13f5014add7f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_d7add7954f86bd13f5014add7f" ON public.payment_webhooks USING btree (tx_hash);


--
-- Name: IDX_d8f8d3788694e1b3f96c42c36f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_d8f8d3788694e1b3f96c42c36f" ON public.invoices USING btree (invoice_number);


--
-- Name: IDX_fcff0e18e3512fcef5e52c9172; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fcff0e18e3512fcef5e52c9172" ON public.wallet_ledgers USING btree (tx_hash);


--
-- Name: recharges FK_2d9148851483713298bbb2e64d9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recharges
    ADD CONSTRAINT "FK_2d9148851483713298bbb2e64d9" FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- PostgreSQL database dump complete
--

\unrestrict mz8KeBqdSfyr0lzDtUhppbXxIUxbSXJc27aw1bN0oNEDhY0yCKqNU9mCIL3B4U5

